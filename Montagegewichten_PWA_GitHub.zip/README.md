# Montagegewichten (PWA)

Een eenvoudige Progressive Web App om gewichten per kraantype en gieklengte te raadplegen.

## 🚀 Gebruik

```bash
npm install
npm run build
npm run deploy
```

De app wordt automatisch gepubliceerd naar:
👉 https://DieterVO84.github.io/Montagegewichten

## 📱 Installatie op Android
Open de link in Chrome en kies **"Toevoegen aan startscherm"**.
